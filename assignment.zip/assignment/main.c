#include <stdio.h>
#include "mylib.h"
#include "arraylib.h"

int main() {
    int choice, num;

    do {
        printf("\n===== MENU =====\n");
        printf("1. Check Armstrong Number\n");
        printf("2. Check Adams Number\n");
        printf("3. Check Prime Palindrome Number\n");
        printf("4. Array Operations\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 5) {
            printf("Exiting program. Goodbye!\n");
            break;
        }

        switch (choice) {
            case 1:
                printf("Enter a number: ");
                scanf("%d", &num);
                if (isArmstrong(num))
                    printf("%d is an Armstrong number.\n", num);
                else
                    printf("%d is NOT an Armstrong number.\n", num);
                break;

            case 2:
                printf("Enter a number: ");
                scanf("%d", &num);
                if (isAdams(num))
                    printf("%d is an Adams number.\n", num);
                else
                    printf("%d is NOT an Adams number.\n", num);
                break;

            case 3:
                printf("Enter a number: ");
                scanf("%d", &num);
                if (isPrimePalindrome(num))
                    printf("%d is a Prime Palindrome number.\n", num);
                else
                    printf("%d is NOT a Prime Palindrome number.\n", num);
                break;

            case 4: {
                int arr[] = {3, 1, 4, 1, 5};
                int n = 5;
                printf("\nOriginal Array: ");
                displayArray(arr, n);
                printf("Max index: %d\n", findMaxIndex(arr, n));
                printf("Min index: %d\n", findMinIndex(arr, n));
                printf("Average: %.2f\n", findAverage(arr, n));
                reverseArray(arr, n);
                printf("Reversed Array: ");
                displayArray(arr, n);
                sortArray(arr, n);
                printf("Sorted Array: ");
                displayArray(arr, n);
                int value;
                printf("Enter value to search: ");
                scanf("%d", &value);
                int idx = linearSearch(arr, n, value);
                if (idx != -1)
                    printf("%d found at index %d\n", value, idx);
                else
                    printf("%d not found in array.\n", value);
                break;
            }

            default:
                printf("Invalid choice! Please select 1–5.\n");
        }
    } while (choice != 5);

    return 0;
}