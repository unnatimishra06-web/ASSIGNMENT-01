#include "mylib.h"

// #Cp

// Function to reverse digits of a number
int reverseDigits(int n) {
    int r = 0;
    while (n) {
        r = r * 10 + (n % 10);
        n /= 10;
    }
    return r;
}

// Function to check Armstrong number
int isArmstrong(int num) {
    int temp = num, sum = 0, d;
    while (temp > 0) {
        d = temp % 10;
        sum += d * d * d;
        temp /= 10;
    }
    return sum == num;
}

// Function to check Adams number
int isAdams(int num) {
    int sq = num * num;
    int rev_sq = reverseDigits(sq);
    int rev_num = reverseDigits(num);
    return (rev_sq == rev_num * rev_num);
}

// Function to check Prime number
int isPrime(int num) {
    if (num <= 1) return 0;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) return 0;
    }
    return 1;
}

// Function to check Prime Palindrome
int isPrimePalindrome(int num) {
    return (isPrime(num) && num == reverseDigits(num));
}