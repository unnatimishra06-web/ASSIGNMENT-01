#ifndef MYLIB_H
#define MYLIB_H

int reverseDigits(int n);
int isArmstrong(int num);
int isAdams(int num);
int isPrime(int num);
int isPrimePalindrome(int num);

#endif